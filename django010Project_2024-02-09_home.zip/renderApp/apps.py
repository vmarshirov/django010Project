from django.apps import AppConfig


class RenderAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'renderApp'
