from django.apps import AppConfig


class ResponseAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'responseApp'
