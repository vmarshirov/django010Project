python manage.py -h

python manage.py startapp responseApp

смотрим ../responseApp/apps.py


редактируем project01/settings.py

'responseApp.apps.ResponseappConfig',


http://127.0.0.1:8000/responseApp
